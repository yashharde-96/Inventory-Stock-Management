package com.example.inventory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.CartDTO;
import com.example.inventory.entity.Cart;
import com.example.inventory.entity.Customer;
import com.example.inventory.entity.Product;
import com.example.inventory.mapper.CartMapper;
import com.example.inventory.repository.CartRepository;
import com.example.inventory.repository.CustomerRepository;
import com.example.inventory.repository.ProductRepository;
import com.example.inventory.repository.UserRepository;

import jakarta.transaction.Transactional;
@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public CartDTO addToCart(Long customerId, Long productId, int quantity) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Cart cart = cartRepository
                .findByCustomerAndProduct(customer, product)
                .orElseGet(() -> Cart.builder()
                        .customer(customer)
                        .product(product)
                        .quantity(0)
                        .build());

        cart.setQuantity(cart.getQuantity() + quantity);
        cart.setTotalAmount(cart.getQuantity() * product.getPrice());

        cartRepository.save(cart);
        return CartMapper.toDTO(cart);
    }

    @Override
    @Transactional
    public CartDTO updateQuantity(Long customerId, Long productId, int quantity) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Cart cart = cartRepository.findByCustomerAndProduct(customer, product)
                .orElseThrow(() -> new RuntimeException("Product not present in cart"));

        cart.setQuantity(quantity);
        cart.setTotalAmount(quantity * product.getPrice());

        cartRepository.save(cart);
        return CartMapper.toDTO(cart);
    }
    
    @Override
    @Transactional
    public void removeFromCart(Long customerId, Long productId) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        cartRepository.findByCustomerAndProduct(customer, product)
                .ifPresent(cartRepository::delete);
    }

    @Override
    public List<CartDTO> getCart(Long customerId) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return cartRepository.findByCustomer_Id(customer.getId())
                .stream()
                .map(CartMapper::toDTO)
                .toList();
    }

    @Override
    @Transactional
    public void deleteCart(Long userId) {

        Customer customer = customerRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        cartRepository.deleteByCustomer_Id(customer.getId());
    }
}
