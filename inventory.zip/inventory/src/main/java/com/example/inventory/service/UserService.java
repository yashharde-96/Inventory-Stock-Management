package com.example.inventory.service;

import com.example.inventory.dto.UserDTO;
import java.util.List;

public interface UserService {

    UserDTO getUserById(Long id);         
    List<UserDTO> getAllUsers();          
    UserDTO updateMyProfile(Long userIdFromToken, UserDTO dto);
    UserDTO adminUpdateUser(Long id, UserDTO dto);
    void deleteUser(Long id);
    boolean verifyOtp(String email, String otp);
    void updatePassword(Long userId, String oldPassword, String newPassword, String confirmPassword);
    void forgotPassword(String email);
    void resetPassword(String email, String otp, String newPassword, String confirmPassword);
    void resendOtp(String email);
    
}