package com.example.inventory.util;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtils {

    private static final String SECRET =
            "inventory-management-secret-key-inventory-management";
    private static final long EXPIRATION = 86400000;

    private static final ThreadLocal<Long> userIdHolder = new ThreadLocal<>();

    private final Key key = Keys.hmacShaKeyFor(SECRET.getBytes());

    public String generateToken(Long userId, String role) {

        return Jwts.builder()
                .setSubject(String.valueOf(userId))
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    public Claims getClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public void storeUserId(String token) {
        Claims claims = getClaims(token);
        userIdHolder.set(Long.parseLong(claims.getSubject()));
    }

    public static Long getUserIdFromToken() {
        return userIdHolder.get();
    }

    public void clear() {
        userIdHolder.remove();
    }
}
