package com.example.inventory.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RegisterRequest {

    private String name;
    private String email;
    private String password;
    private String roleName;
    private String mobileNo;   
    private String address;
    private Long dealerId;

    private String companyName;
    private String gstNumber;
    private String dealerType;
}
