package com.example.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendEmail(String toEmail, String subject, String body) {

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject(subject);
        message.setText(body);

        mailSender.send(message);
    }

    public void sendOtp(String toEmail, String otp) {
        sendEmail(toEmail,"Inventory App - Email Verification OTP","Your OTP for email verification is: " + otp + "\n\nThis OTP is valid for 5 minutes.");
    }

    public void sendForgotPasswordOtp(String email, String otp) {
        sendEmail(email, "Password Reset OTP","Your OTP is: " + otp + "\nValid for 2 minutes.");
    }
}
