package com.example.inventory.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthRequest {

    private String name;
    private String email;
    private String password;
    private String roleName;
    private String mobileNo;
    private String address;

}
