package com.example.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.AuthRequest;
import com.example.inventory.dto.AuthResponse;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.entity.Admin;
import com.example.inventory.entity.Customer;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Role;
import com.example.inventory.entity.User;
import com.example.inventory.mapper.UserMapper;
import com.example.inventory.repository.AdminRepository;
import com.example.inventory.repository.CustomerRepository;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.RoleRepository;
import com.example.inventory.repository.UserRepository;
import com.example.inventory.util.JwtUtils;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private DealerRepository dealerRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @Override
    public UserDTO register(AuthRequest request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already registered");
        }

        Role userRole = roleRepository.findByName(request.getRole())
                .orElseThrow(() -> new RuntimeException("Role not found"));

        User user = new User();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(userRole);
        user.setStatus("ACTIVE");

        // New fields
        user.setName(request.getName());
        user.setMobileNo(request.getMobileNo());
        user.setAddress(request.getAddress());

        user = userRepository.save(user);

        // Save in specific table
        switch (userRole.getName()) {
            case "ADMIN":
                Admin admin = new Admin();
                admin.setUser(user);
                adminRepository.save(admin);
                break;
            case "DEALER":
                Dealer dealer = new Dealer();
                dealer.setUser(user);
                dealerRepository.save(dealer);
                break;
            case "CUSTOMER":
                Customer customer = new Customer();
                customer.setUser(user);
                customerRepository.save(customer);
                break;
            default:
                throw new RuntimeException("Invalid role");
        }

        return UserMapper.toDTO(user);
    }

    @Override
    public AuthResponse login(AuthRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        // Generate JWT using Role entity
        String token = jwtUtils.generateToken(user.getEmail(), user.getRole().getName());

        return new AuthResponse(token, user.getEmail(), user.getRole());
    }

    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }
}
