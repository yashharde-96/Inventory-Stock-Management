package com.example.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.AuthRequest;
import com.example.inventory.dto.AuthResponse;
import com.example.inventory.dto.RegisterRequest;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.entity.Admin;
import com.example.inventory.entity.Customer;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Role;
import com.example.inventory.entity.User;
import com.example.inventory.mapper.UserMapper;
import com.example.inventory.repository.AdminRepository;
import com.example.inventory.repository.CustomerRepository;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.RoleRepository;
import com.example.inventory.repository.UserRepository;
import com.example.inventory.util.JwtUtils;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private DealerRepository dealerRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    public AuthServiceImpl(PasswordEncoder passwordEncoder, UserRepository userRepository) {
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
    }

    @Override
    public UserDTO register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        Role role = roleRepository.findByName(Role.RoleName.valueOf(request.getRoleName()))
                .orElseThrow(() -> new RuntimeException("Role not found"));

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .mobileNo(request.getMobileNo())
                .address(request.getAddress())
                .role(role)
                .build();


        userRepository.save(user);

        switch (role.getName()) {

            case ADMIN -> adminRepository.save(new Admin(user));

            case DEALER -> {
                Dealer dealer = Dealer.builder()
                        .user(user)
                        .companyName(request.getCompanyName())
                        .gstNumber(request.getGstNumber())
                        .dealerType(request.getDealerType())
                        .build();

                dealerRepository.save(dealer);
            }

            case CUSTOMER -> {
                if (request.getDealerId() == null) {
                    throw new RuntimeException("dealerId is required for CUSTOMER");
                }

                Dealer dealer = dealerRepository.findById(request.getDealerId())
                        .orElseThrow(() -> new RuntimeException("Dealer not found"));

                Customer customer = Customer.builder()
                        .user(user)
                        .dealer(dealer)
                        .build();

                customerRepository.save(customer);
            }
        }

        return UserMapper.toDTO(user);
    }

    @Override
    public AuthResponse login(AuthRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtUtils.generateToken(user.getId(), user.getRole().getName().name());

        return AuthResponse.builder()
                .token(token)
                .userId(user.getId())
                .role(user.getRole().getName().name())
                .build();
    }

    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

}