package com.example.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.AuthRequest;
import com.example.inventory.dto.AuthResponse;
import com.example.inventory.dto.RegisterRequest;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.entity.Admin;
import com.example.inventory.entity.Customer;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Role;
import com.example.inventory.entity.User;
import com.example.inventory.mapper.UserMapper;
import com.example.inventory.repository.AdminRepository;
import com.example.inventory.repository.CustomerRepository;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.RoleRepository;
import com.example.inventory.repository.UserRepository;
import com.example.inventory.util.JwtUtils;


@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private DealerRepository dealerRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private OtpService otpService;

    @Autowired
    private JwtUtils jwtUtils;

    public AuthServiceImpl(PasswordEncoder passwordEncoder, UserRepository userRepository) {
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
    }

    @Override
    public UserDTO register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        Role role = roleRepository.findByName(
                Role.RoleName.valueOf(request.getRoleName()))
                .orElseThrow(() -> new RuntimeException("Role not found"));

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail().trim().toLowerCase())
                .password(passwordEncoder.encode(request.getPassword()))
                .mobileNo(request.getMobileNo())
                .address(request.getAddress())
                .role(role)
                .emailVerified(false)
                .status("PENDING")
                .build();

        userRepository.save(user);

        switch (role.getName()) {
            case ADMIN -> {
                String adminId = "ADM" + (adminRepository.count() + 1);
                adminRepository.save(Admin.builder().adminId(adminId).user(user).build());
                user.setAdminId(adminId);
            }
            case DEALER -> {
                String dealerId = "DEL" + (dealerRepository.count() + 1);
                dealerRepository.save(
                    Dealer.builder()
                        .dealerId(dealerId)
                        .user(user)
                        .companyName(request.getCompanyName())
                        .gstNumber(request.getGstNumber())
                        .dealerType(request.getDealerType())
                        .build()
                );
                user.setDealerId(dealerId);
            }
            case CUSTOMER -> {
                String customerId = "CUS" + (customerRepository.count() + 1);
                Dealer dealer = dealerRepository.findById(request.getDealerId()).orElseThrow(() -> new RuntimeException("Dealer not found"));
                customerRepository.save( Customer.builder().customerId(customerId).user(user).dealer(dealer).build());
                user.setCustomerId(customerId);
            }
        }

        userRepository.save(user);

        return UserMapper.toDTO(user);
    }


    @Override
    public AuthResponse login(AuthRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!user.isEmailVerified()) {
            throw new RuntimeException("OTP not verified");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtUtils.generateToken(user.getId(),user.getRole().getName().name());

        return AuthResponse.builder().token(token).userId(user.getId()).role(user.getRole().getName().name()).build();
    }



    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
    }

}