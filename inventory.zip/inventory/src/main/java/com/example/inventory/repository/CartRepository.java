package com.example.inventory.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventory.entity.Cart;
import com.example.inventory.entity.Customer;
import com.example.inventory.entity.Product;

public interface CartRepository extends JpaRepository<Cart, Long> {

    List<Cart> findByCustomer_Id(Long userId);
    List<Cart> findByCustomer(Customer customer);
    Optional<Cart> findByCustomerAndProduct(Customer customer, Product product);
    Optional<Cart> findByCustomer_IdAndProduct_Id(Long userId, Long productId);
    void deleteByProduct_Id(Long productId);
    void deleteByCustomer_Id(Long userId);
    void deleteByProduct(Product product);
    void deleteByCustomer(Customer customer);
}
