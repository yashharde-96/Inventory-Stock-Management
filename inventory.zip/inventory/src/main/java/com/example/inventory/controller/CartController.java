package com.example.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.dto.BaseResponseDTO;
import com.example.inventory.dto.CartDTO;
import com.example.inventory.service.CartService;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public ResponseEntity<CartDTO> addToCart(@RequestParam Long customerId,
                                             @RequestParam Long productId,
                                             @RequestParam int quantity) {
        return ResponseEntity.ok(
                cartService.addToCart(customerId, productId, quantity)
        );
    }

    @PutMapping("/update")
    public ResponseEntity<CartDTO> updateQuantity(@RequestParam Long customerId,
                                                  @RequestParam Long productId,
                                                  @RequestParam int quantity) {
        return ResponseEntity.ok(
                cartService.updateQuantity(customerId, productId, quantity)
        );
    }

    @DeleteMapping("/remove")
    public ResponseEntity<String> removeFromCart(@RequestParam Long customerId,
                                                 @RequestParam Long productId) {
        cartService.removeFromCart(customerId, productId);
        return ResponseEntity.ok("Removed from cart");
    }

    @GetMapping
    public ResponseEntity<List<CartDTO>> getCart(@RequestParam Long customerId) {
        return ResponseEntity.ok(cartService.getCart(customerId));
    }

    @DeleteMapping("/clear")
    @PreAuthorize("hasAuthority('CUSTOMER')")
    public BaseResponseDTO<Void> clearCart(Authentication authentication) {

        Long userId = Long.parseLong(authentication.getName());
        cartService.deleteCart(userId);

        return new BaseResponseDTO<>("success", "Cart cleared successfully", null);
    }
}
