package com.example.inventory.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.UserDTO;
import com.example.inventory.entity.Customer;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;
import com.example.inventory.entity.User;
import com.example.inventory.mapper.UserMapper;
import com.example.inventory.repository.CartRepository;
import com.example.inventory.repository.CustomerRepository;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.ProductRepository;
import com.example.inventory.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CustomerRepository customerRepository;
    
    @Autowired
    private DealerRepository dealerRepository;
    
    @Autowired
    private CartRepository cartRepository;
    
    @Autowired
    private ProductRepository productRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private EmailService emailService;


    @Override
    public UserDTO getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return UserMapper.toDTO(user);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map(UserMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public UserDTO updateMyProfile(Long userIdFromToken, UserDTO dto) {
        User user = userRepository.findById(userIdFromToken)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setMobileNo(dto.getMobileNo());
        user.setAddress(dto.getAddress());

        userRepository.save(user);
        return UserMapper.toDTO(user);
    }

    @Override
    public UserDTO adminUpdateUser(Long id, UserDTO dto) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setMobileNo(dto.getMobileNo());
        user.setAddress(dto.getAddress());

        userRepository.save(user);
        return UserMapper.toDTO(user);
    }

    @Transactional
    @Override
    public void deleteUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        switch (user.getRole().getName()) {
            case DEALER -> {

                Dealer dealer = dealerRepository.findByUserId(userId)
                        .orElseThrow(() -> new RuntimeException("Dealer not found"));

                org.springframework.data.domain.Page<Product> dealerProductsPage =
                        productRepository.findByDealer(dealer, org.springframework.data.domain.Pageable.unpaged());
                List<Product> dealerProducts = dealerProductsPage.getContent();
                for (Product product : dealerProducts) {
                	
                    cartRepository.deleteByProduct_Id(product.getId());
                    productRepository.delete(product);
                }

                dealerRepository.delete(dealer);
                
                userRepository.delete(user);
            }

            case CUSTOMER -> {

                cartRepository.deleteByCustomer_Id(userId);

                Customer customer = customerRepository.findByUserId(userId)
                        .orElseThrow(() -> new RuntimeException("Customer not found"));
                customerRepository.delete(customer);

                userRepository.delete(user);
            }

            default -> throw new RuntimeException("Unsupported role for deletion");
        }
    }
    
    @Override
    public boolean verifyOtp(String email, String otp) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));

        return otp.equals(user.getOtp()) && user.getOtpExpiry().isAfter(LocalDateTime.now());
    }

	@Transactional
	@Override
	public void updatePassword(Long userId, String oldPassword, String newPassword, String confirmPassword) {
	    User user = userRepository.findById(userId)
	            .orElseThrow(() -> new RuntimeException("User not found"));

	    if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
	        throw new RuntimeException("Old password is incorrect");
	    }

	    if (!newPassword.equals(confirmPassword)) {
	        throw new RuntimeException("New password and confirm password do not match");
	    }

	    user.setPassword(passwordEncoder.encode(newPassword));
	    userRepository.save(user);
	}


	@Transactional
	@Override
	public void forgotPassword(String email) {
	    User user = userRepository.findByEmail(email)
	            .orElseThrow(() -> new RuntimeException("User not found"));

	    String otp = String.valueOf((int)(Math.random() * 900000) + 100000);
	    user.setOtp(otp);
	    user.setOtpExpiry(LocalDateTime.now().plusMinutes(5));
	    userRepository.save(user);

	    emailService.sendOtp(user.getEmail(), otp);
	}


	@Transactional
	@Override
	public void resetPassword(String email, String otp, String newPassword, String confirmPassword) {
	    User user = userRepository.findByEmail(email)
	            .orElseThrow(() -> new RuntimeException("User not found"));

	    if (!otp.equals(user.getOtp()) || user.getOtpExpiry().isBefore(LocalDateTime.now())) {
	        throw new RuntimeException("Invalid or expired OTP");
	    }

	    if (!newPassword.equals(confirmPassword)) {
	        throw new RuntimeException("New password and confirm password do not match");
	    }

	    user.setPassword(passwordEncoder.encode(newPassword));
	    user.setOtp(null);
	    user.setOtpExpiry(null);
	    userRepository.save(user);
	}
	
	@Transactional
	@Override
	public void resendOtp(String email) {
	    User user = userRepository.findByEmail(email)
	            .orElseThrow(() -> new RuntimeException("User not found"));

	    if (user.getOtpExpiry() != null && user.getOtpExpiry().isAfter(LocalDateTime.now())) {
	        throw new RuntimeException("OTP not expired yet. Please wait.");
	    }

	    String otp = String.valueOf((int)(Math.random() * 900000) + 100000);
	    user.setOtp(otp);
	    user.setOtpExpiry(LocalDateTime.now().plusMinutes(2));
	    userRepository.save(user);

	    emailService.sendOtp(user.getEmail(), otp);
	}

    
}