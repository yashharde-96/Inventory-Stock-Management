package com.example.inventory.mapper;

import com.example.inventory.dto.CartDTO;
import com.example.inventory.entity.Cart;
import com.example.inventory.entity.Product;

public class CartMapper {

    public static CartDTO toDTO(Cart cart) {

        Product product = cart.getProduct();

        return CartDTO.builder()
                .cartId(cart.getId())
                .productId(product.getId())
                .productName(product.getName())
                .productBrand(product.getBrand())
                .productCategory(product.getCategory())
                .productDescription(product.getDescription())
                .productPrice(product.getPrice())
                .quantity(cart.getQuantity())
                .totalAmount(cart.getTotalAmount())
                .build();
    }
}
