package com.example.inventory.service;

import com.example.inventory.dto.AuthRequest;
import com.example.inventory.dto.AuthResponse;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.entity.User;

public interface AuthService {
    UserDTO register(AuthRequest request);
    AuthResponse login(AuthRequest request);
    User findByEmail(String email);
}
