package com.example.inventory.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.inventory.dto.ProductDTO;

public interface ProductService {
	
	List<ProductDTO> getAllProducts();
	List<ProductDTO> getLowStock(Long userId);
    ProductDTO createProduct(ProductDTO dto, Long userId);
    ProductDTO updateProduct(Long productId, ProductDTO dto, Long userId);
    void deleteProduct(Long productId, Long userId);
    ProductDTO getProduct(Long productId);
    Page<ProductDTO> getAllProducts(String category, String brand, Pageable pageable);
    ProductDTO updateStock(Long productId, int delta, Long userId);
    
}