package com.example.inventory.service;

import com.example.inventory.dto.ProductDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProductService {

    ProductDTO createProduct(ProductDTO dto);

    ProductDTO getProduct(Long id);

    Page<ProductDTO> getAllProducts(String category, String brand, Pageable pageable);

    ProductDTO updateProduct(Long id, ProductDTO dto);

    void deleteProduct(Long id);

    ProductDTO updateStock(Long productId, int delta, Long dealerId);
}
