package com.example.inventory.mapper;

import com.example.inventory.dto.AdminDTO;
import com.example.inventory.entity.Admin;

public class AdminMapper {

    public static AdminDTO toDTO(Admin admin) {
        if (admin == null) return null;

        return new AdminDTO(
                admin.getId(),
                admin.getUser().getId()
        );
    }
}
