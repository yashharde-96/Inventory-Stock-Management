package com.example.inventory.mapper;

import com.example.inventory.dto.AdminDTO;
import com.example.inventory.entity.Admin;

public final class AdminMapper {

    private AdminMapper() {}

    public static AdminDTO toDTO(Admin admin) {
        if (admin == null) return null;

        return AdminDTO.builder()
                .id(admin.getId())
                .userId(admin.getUser().getId())
                .build();
    }
}
