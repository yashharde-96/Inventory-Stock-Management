package com.example.inventory.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.User;

public interface DealerRepository extends JpaRepository<Dealer, Long> {
    Optional<Dealer> findByUserId(Long userId);
    Optional<Dealer> findByUser(User user);
    long count();
}