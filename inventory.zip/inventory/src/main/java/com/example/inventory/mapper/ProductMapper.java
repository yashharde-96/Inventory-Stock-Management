package com.example.inventory.mapper;

import com.example.inventory.dto.ProductDTO;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;

public class ProductMapper {

    public static Product toEntity(ProductDTO dto) {

        Product product = new Product();
        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setBrand(dto.getBrand());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setMinStockLevel(dto.getMinStockLevel());

        return product;
    }

    public static Product toEntity(ProductDTO dto, Dealer dealer) {

        Product product = toEntity(dto);
        product.setDealer(dealer);

        return product;
    }

    public static ProductDTO toDTO(Product product) {

        ProductDTO dto = new ProductDTO();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setCategory(product.getCategory());
        dto.setBrand(product.getBrand());
        dto.setDescription(product.getDescription());
        dto.setPrice(product.getPrice());
        dto.setQuantity(product.getQuantity());
        dto.setMinStockLevel(product.getMinStockLevel());

        if (product.getDealer() != null) {
            dto.setDealerId(product.getDealer().getId());
        }

        return dto;
    }

    public static void updateEntity(ProductDTO dto, Product product) {

        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setBrand(dto.getBrand());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setMinStockLevel(dto.getMinStockLevel());
    }
}
