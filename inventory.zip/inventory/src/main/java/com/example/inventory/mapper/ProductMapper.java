package com.example.inventory.mapper;

import com.example.inventory.dto.ProductDTO;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;

public class ProductMapper {

    public static ProductDTO toDTO(Product product) {
        return new ProductDTO(
                product.getId(),
                product.getName(),
                product.getCategory(),
                product.getBrand(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity(),
                product.getMinStockLevel(),
                product.getDealer() != null ? product.getDealer().getId() : null
        );
    }

    public static Product toEntity(ProductDTO dto, Dealer dealer) {
        Product product = new Product();

        product.setId(dto.getId());
        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setBrand(dto.getBrand());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setMinStockLevel(dto.getMinStockLevel());
        product.setDealer(dealer);

        return product;
    }
}
