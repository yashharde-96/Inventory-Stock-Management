package com.example.inventory.controller;

import com.example.inventory.dto.AuthRequest;
import com.example.inventory.dto.AuthResponse;
import com.example.inventory.dto.RegisterRequest;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public UserDTO register(@RequestBody RegisterRequest request) {
        return authService.register(request);
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest request) {
        return authService.login(request);
    }

}