package com.example.inventory.controller;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.dto.AuthRequest;
import com.example.inventory.dto.AuthResponse;
import com.example.inventory.dto.ForgotPasswordRequest;
import com.example.inventory.dto.RegisterRequest;
import com.example.inventory.dto.ResetPasswordRequest;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.dto.VerifyOtpRequest;
import com.example.inventory.entity.User;
import com.example.inventory.repository.UserRepository;
import com.example.inventory.service.AuthService;
import com.example.inventory.service.EmailService;
import com.example.inventory.service.OtpService;
import com.example.inventory.util.OtpUtil;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final OtpService otpService;
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PasswordEncoder passwordEncoder;


    public AuthController(AuthService authService, OtpService otpService) {
        this.authService = authService;
        this.otpService = otpService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {

    	UserDTO userDTO = authService.register(request);
    	
    	otpService.generateOtp(userDTO.getEmail());

        return ResponseEntity.ok("OTP sent to email. Please verify.");
    }
    
    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOtp(@RequestBody VerifyOtpRequest request) {
        otpService.verifyOtp(request.getEmail(), request.getOtp());
        return ResponseEntity.ok(Map.of(
            "status", "success",
            "message", "OTP verified successfully"
        ));
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest request) {
        return authService.login(request);
    }
    
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(
            @RequestBody ForgotPasswordRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Email not registered"));

        String otp = OtpUtil.generateOtp();

        user.setForgotPasswordOtp(otp);
        user.setOtpExpiryTime(LocalDateTime.now().plusMinutes(2));

        userRepository.save(user);
        emailService.sendForgotPasswordOtp(user.getEmail(), otp);

        return ResponseEntity.ok("OTP sent to email");
    }
    
    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email"));

        if (user.getForgotPasswordOtp() == null) {
            throw new RuntimeException("OTP not found");
        }

        if (!user.getForgotPasswordOtp().equals(request.getOtp())) {
            throw new RuntimeException("Invalid OTP");
        }

        if (user.getOtpExpiryTime().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("OTP expired");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setForgotPasswordOtp(null);
        user.setOtpExpiryTime(null);

        userRepository.save(user);

        return ResponseEntity.ok("Password reset successful");
    }

    
    @PostMapping("/resend-otp")
    public ResponseEntity<String> resendOtp(
            @RequestBody ForgotPasswordRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Email not registered"));

        String otp = OtpUtil.generateOtp();

        user.setForgotPasswordOtp(otp);
        user.setOtpExpiryTime(LocalDateTime.now().plusMinutes(2));

        userRepository.save(user);
        emailService.sendForgotPasswordOtp(user.getEmail(), otp);

        return ResponseEntity.ok("OTP resent successfully");
    }

}
