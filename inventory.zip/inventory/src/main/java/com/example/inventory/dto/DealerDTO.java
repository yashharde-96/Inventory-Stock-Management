package com.example.inventory.dto;

public class DealerDTO {

    private Long id;
    private Long userId;
    private String companyName;
    private String gstNumber;
    private String dealerType;

    public DealerDTO() {}

    public DealerDTO(Long id, Long userId, String companyName,
                     String gstNumber, String dealerType) {
        this.id = id;
        this.userId = userId;
        this.companyName = companyName;
        this.gstNumber = gstNumber;
        this.dealerType = dealerType;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    public String getGstNumber() { return gstNumber; }
    public void setGstNumber(String gstNumber) { this.gstNumber = gstNumber; }

    public String getDealerType() { return dealerType; }
    public void setDealerType(String dealerType) { this.dealerType = dealerType; }
}
