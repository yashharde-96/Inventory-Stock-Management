package com.example.inventory.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DealerDTO {

    private Long id;
    private Long userId;
    private String companyName;
    private String gstNumber;
    private String dealerType;
}
