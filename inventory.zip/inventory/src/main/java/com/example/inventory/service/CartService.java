package com.example.inventory.service;

import java.util.List;

import com.example.inventory.dto.CartDTO;

public interface CartService {

    CartDTO addToCart(Long customerId, Long productId, int quantity);
    CartDTO updateQuantity(Long customerId, Long productId, int quantity);
    void removeFromCart(Long customerId, Long productId);
    List<CartDTO> getCart(Long customerId);
    void deleteCart(Long customerId);
}
