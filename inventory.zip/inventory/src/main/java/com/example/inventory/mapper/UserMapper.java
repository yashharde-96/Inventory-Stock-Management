package com.example.inventory.mapper;

import com.example.inventory.dto.UserDTO;
import com.example.inventory.entity.User;

public class UserMapper {

    public static UserDTO toDTO(User user) {
        return new UserDTO(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getRole(),
                user.getMobileNo(),
                user.getAddress(),
                user.getStatus()
        );
    }

    public static User toEntity(UserDTO dto) {
        User user = new User();
        user.setId(dto.getId());
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setRole(dto.getRole());
        user.setMobileNo(dto.getMobileNo());
        user.setAddress(dto.getAddress());
        user.setStatus(dto.getStatus());
        return user;
    }
}

