package com.example.inventory.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "dealers")
public class Dealer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;
    @Column(name = "company_name")
    private String companyName;
    @Column(name = "gst_number", unique = true)
    private String gstNumber;
    @Column(name = "dealer_type")
    private String dealerType; 
    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();
    public Dealer() {}
    public Dealer(User user) {
        this.user = user;
    }

    public Dealer(Long id, User user, String companyName, String gstNumber, String dealerType, LocalDateTime createdAt) {
        this.id = id;
        this.user = user;
        this.companyName = companyName;
        this.gstNumber = gstNumber;
        this.dealerType = dealerType;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(String gstNumber) {
        this.gstNumber = gstNumber;
    }

    public String getDealerType() {
        return dealerType;
    }

    public void setDealerType(String dealerType) {
        this.dealerType = dealerType;
    }

	public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
