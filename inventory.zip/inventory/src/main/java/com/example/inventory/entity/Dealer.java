package com.example.inventory.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "dealers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Dealer {

    @Id
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "id") 
    private User user;
    
    @Column(name = "dealer_Id", unique = true)
    private String dealerId;

    @Column(name = "company_name", nullable = false)
    private String companyName;

    @Column(name = "gst_number", unique = true)
    private String gstNumber;

    @Column(name = "dealer_type")
    private String dealerType;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    public void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }

    public Dealer(User user) {
        this.user = user;
    }
}
