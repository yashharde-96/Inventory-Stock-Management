package com.example.inventory.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventory.entity.Customer;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.User;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Optional<Customer> findByUserId(Long userId);
    Optional<Dealer> findByUser(User user);
    void deleteByUserId(Long userId);
    long count();
}
