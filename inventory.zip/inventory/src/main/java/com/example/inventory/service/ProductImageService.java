package com.example.inventory.service;

import org.springframework.web.multipart.MultipartFile;

public interface ProductImageService {
    void uploadImage(Long productId, Long userId, MultipartFile file) throws Exception;
    byte[] getImage(Long productId) throws Exception;
}

