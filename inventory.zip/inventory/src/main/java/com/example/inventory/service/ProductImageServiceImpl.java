package com.example.inventory.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.inventory.entity.Product;
import com.example.inventory.entity.Role;
import com.example.inventory.entity.User;
import com.example.inventory.repository.ProductRepository;
import com.example.inventory.repository.UserRepository;

@Service
public class ProductImageServiceImpl implements ProductImageService {

    private static final String UPLOAD_DIR = "uploads";

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void uploadImage(Long productId, Long userId, MultipartFile file) throws Exception {

        if (file == null || file.isEmpty()) {
            throw new RuntimeException("Image file is required");
        }

        if (!file.getContentType().startsWith("image/")) {
            throw new RuntimeException("Only image files are allowed");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        if (user.getRole().getName() == Role.RoleName.DEALER &&
            !product.getDealer().getUser().getId().equals(userId)) {

            throw new RuntimeException("You are not allowed to upload image for this product");
        }

        Path uploadPath = Paths.get(UPLOAD_DIR);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
        Path filePath = uploadPath.resolve(fileName);

        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        product.setImageUrl(filePath.toString());
        productRepository.save(product);
    }

    @Override
    public byte[] getImage(Long productId) throws Exception {

        Product product = productRepository.findById(productId).orElseThrow(() -> new RuntimeException("Product not found"));

        if (product.getImageUrl() == null) {
            throw new RuntimeException("Image not found");
        }

        Path imagePath = Paths.get(product.getImageUrl());

        if (!Files.exists(imagePath)) {
            throw new RuntimeException("Image file missing on server");
        }

        return Files.readAllBytes(imagePath);
    }
}
