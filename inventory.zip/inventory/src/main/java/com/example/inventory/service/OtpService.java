package com.example.inventory.service;

public interface OtpService {
    void generateOtp(String email);
    void verifyOtp(String email, String otp);
}
