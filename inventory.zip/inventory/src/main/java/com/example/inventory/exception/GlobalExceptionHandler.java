package com.example.inventory.exception;

import com.example.inventory.dto.BaseResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public BaseResponseDTO<String> handleRuntimeException(RuntimeException ex) {
        return new BaseResponseDTO<>("error",ex.getMessage(),null);
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public BaseResponseDTO<String> handleException(Exception ex) {
        return new BaseResponseDTO<>("error","Internal server error: " + ex.getMessage(),null);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public BaseResponseDTO<String> handleNotFound(ResourceNotFoundException ex) {
        return new BaseResponseDTO<>("error",ex.getMessage(),null);
    }
}
