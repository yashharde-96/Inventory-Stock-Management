package com.example.inventory.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.dto.BaseResponseDTO;
import com.example.inventory.dto.ProductDTO;
import com.example.inventory.entity.User;
import com.example.inventory.repository.UserRepository;
import com.example.inventory.service.AuthService;
import com.example.inventory.service.ProductService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/products")
@SecurityRequirement(name = "BearerAuth")
public class ProductController {
	
	@Autowired
	private AuthService authService;
	  
	@Autowired
	private UserRepository userRepository;

    @Autowired
    private ProductService productService;

    @PostMapping
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER')")
    public BaseResponseDTO<ProductDTO> createProduct(
            @RequestBody ProductDTO dto,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if ("DEALER".equals(user.getRole().getName().name())) {
            dto.setDealerId(user.getId());
        }

        ProductDTO created = productService.createProduct(dto, user.getId());
        return new BaseResponseDTO<>("success", "Product created", created);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER')")
    public BaseResponseDTO<ProductDTO> updateProduct(
            @PathVariable Long id,
            @RequestBody ProductDTO dto,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());

        ProductDTO updated = productService.updateProduct(id, dto, userId);

        return new BaseResponseDTO<>("success", "Product updated", updated);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER')")
    public BaseResponseDTO<Void> deleteProduct(
            @PathVariable Long id,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());

        productService.deleteProduct(id, userId);

        return new BaseResponseDTO<>("success", "Product deleted", null);
    }

    @GetMapping("/{id}")
    public BaseResponseDTO<ProductDTO> getProduct(@PathVariable Long id) {

        return new BaseResponseDTO<>("success","Product fetched",productService.getProduct(id));
    }

    @GetMapping
    public BaseResponseDTO<Page<ProductDTO>> getAllProducts(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String brand,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Page<ProductDTO> products = productService.getAllProducts(
                category,
                brand,
                PageRequest.of(page, size, Sort.by("id").descending()));

        return new BaseResponseDTO<>("success", "Products fetched", products);
    }

    @GetMapping("/low-stock")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<List<ProductDTO>> getLowStockProducts() {

        List<ProductDTO> lowStockProducts = productService
                .getAllProducts(null, null, PageRequest.of(0, 1000))
                .getContent()
                .stream()
                .filter(p -> p.getQuantity() <= p.getMinStockLevel())
                .toList();

        return new BaseResponseDTO<>("success", "Low stock products", lowStockProducts);
    }

    @PatchMapping("/{id}/stock")
    @PreAuthorize("hasAuthority('DEALER')")
    public BaseResponseDTO<ProductDTO> updateStock(
            @PathVariable Long id,
            @RequestParam int delta,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());

        ProductDTO updated = productService.updateStock(id, delta, userId);

        return new BaseResponseDTO<>("success", "Stock updated", updated);
    }
}
