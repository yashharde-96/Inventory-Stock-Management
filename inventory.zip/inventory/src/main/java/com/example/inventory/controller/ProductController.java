package com.example.inventory.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.inventory.dto.BaseResponseDTO;
import com.example.inventory.dto.ProductDTO;
import com.example.inventory.entity.User;
import com.example.inventory.repository.UserRepository;
import com.example.inventory.service.ProductImageService;
import com.example.inventory.service.ProductService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductImageService productImageService;

    @PostMapping
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER')")
    public BaseResponseDTO<ProductDTO> createProduct(
            @RequestBody ProductDTO dto,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if ("DEALER".equals(user.getRole().getName().name())) {
            dto.setDealerId(user.getId());
        }

        ProductDTO created = productService.createProduct(dto, userId);
        return new BaseResponseDTO<>("success", "Product created", created);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER')")
    public BaseResponseDTO<ProductDTO> updateProduct(
            @PathVariable Long id,
            @RequestBody ProductDTO dto,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());
        ProductDTO updated = productService.updateProduct(id, dto, userId);

        return new BaseResponseDTO<>("success", "Product updated", updated);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER')")
    public BaseResponseDTO<Void> deleteProduct(
            @PathVariable Long id,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());
        productService.deleteProduct(id, userId);

        return new BaseResponseDTO<>("success", "Product deleted", null);
    }

    @GetMapping("/{id}")
    public BaseResponseDTO<ProductDTO> getProduct(@PathVariable Long id) {
        return new BaseResponseDTO<>("success", "Product fetched",
                productService.getProduct(id));
    }

    @GetMapping
    public ResponseEntity<List<ProductDTO>> getAllProducts() {
        return ResponseEntity.ok(productService.getAllProducts());
    }

    @GetMapping("/low-stock")
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER')")
    public BaseResponseDTO<List<ProductDTO>> getLowStockProducts() {

        List<ProductDTO> lowStockProducts = productService
                .getAllProducts(null, null, PageRequest.of(0, 1000))
                .getContent()
                .stream()
                .filter(p -> p.getQuantity() <= p.getMinStockLevel())
                .toList();

        return new BaseResponseDTO<>("success", "Low stock products", lowStockProducts);
    }

    @PatchMapping("/{id}/stock")
    @PreAuthorize("hasAuthority('DEALER')")
    public BaseResponseDTO<ProductDTO> updateStock(
            @PathVariable Long id,
            @RequestParam int delta,
            Principal principal) {

        Long userId = Long.parseLong(principal.getName());
        ProductDTO updated = productService.updateStock(id, delta, userId);

        return new BaseResponseDTO<>("success", "Stock updated", updated);
    }

    @PostMapping(value = "/{productId}/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasAuthority('DEALER')")
    public ResponseEntity<String> uploadImage(
            @PathVariable Long productId,
            @RequestPart("file") MultipartFile file,
            Authentication authentication
    ) throws Exception {

        Long userId = Long.parseLong(authentication.getName());
        productImageService.uploadImage(productId, userId, file);

        return ResponseEntity.ok("Image uploaded successfully");
    }

    @GetMapping("/{productId}/image")
    public ResponseEntity<byte[]> getImage(@PathVariable Long productId) throws Exception {

        byte[] image = productImageService.getImage(productId);
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(image);
    }
}
