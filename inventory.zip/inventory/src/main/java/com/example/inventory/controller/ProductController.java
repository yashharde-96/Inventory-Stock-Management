package com.example.inventory.controller;

import com.example.inventory.dto.BaseResponseDTO;
import com.example.inventory.dto.ProductDTO;
import com.example.inventory.service.ProductService;
import com.example.inventory.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import java.security.Principal;

@RestController
@SecurityRequirement(name = "BearerAuth")
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private AuthService authService;

    @PostMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<ProductDTO> createProduct(@RequestBody ProductDTO dto) {
        return new BaseResponseDTO<>("success", "Product created", productService.createProduct(dto));
    }

    @GetMapping("/{id}")
    public BaseResponseDTO<ProductDTO> getProduct(@PathVariable Long id) {
        return new BaseResponseDTO<>("success", "Product fetched", productService.getProduct(id));
    }

    @GetMapping
    public BaseResponseDTO<Page<ProductDTO>> getAll(
            @RequestParam(value="category", required=false) String category,
            @RequestParam(value="brand", required=false) String brand,
            @RequestParam(value="page", defaultValue="0") int page,
            @RequestParam(value="size", defaultValue="10") int size) {

        PageRequest pageable = PageRequest.of(page, size, Sort.by("id").descending());
        return new BaseResponseDTO<>("success", "Products fetched", productService.getAllProducts(category, brand, pageable));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<ProductDTO> updateProduct(@PathVariable Long id, @RequestBody ProductDTO dto) {
        return new BaseResponseDTO<>("success", "Product updated", productService.updateProduct(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<Void> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return new BaseResponseDTO<>("success", "Product deleted", null);
    }
    
    @GetMapping("/low-stock")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<?> getLowStockProducts() {
        var products = productService.getAllProducts("", "", PageRequest.of(0, 1000))
                .stream()
                .filter(p -> p.getQuantity() <= p.getMinStockLevel())
                .toList();

        return new BaseResponseDTO<>("success", "Low stock products", products);
    }

    @PatchMapping("/{id}/stock")
    @PreAuthorize("hasAuthority('DEALER')")
    public BaseResponseDTO<ProductDTO> updateStock(@PathVariable Long id,
                                                   @RequestParam("delta") int delta,
                                                   Principal principal) {

        Long dealerId = null;
        if(principal != null) {
            var user = authService.findByEmail(principal.getName());
            if(user != null && user.getRole() != null && "DEALER".equals(user.getRole().getName())) {
                dealerId = user.getId();
            }
        }

        return new BaseResponseDTO<>("success", "Stock updated", productService.updateStock(id, delta, dealerId));
    }
}
