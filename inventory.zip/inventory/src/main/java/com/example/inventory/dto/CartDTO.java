package com.example.inventory.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CartDTO {

    private Long cartId;
    private int quantity;
    private double totalAmount;

    private Long productId;
    private String productName;
    private String productCategory;
    private String productBrand;
    private String productDescription;
    private double productPrice;
}
