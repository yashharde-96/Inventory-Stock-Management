package com.example.inventory.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerDTO {

    private Long id;
    private Long userId;
    private String customerType;
    private Integer loyaltyPoints;
}
