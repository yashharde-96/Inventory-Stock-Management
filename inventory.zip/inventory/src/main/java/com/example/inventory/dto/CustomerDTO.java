package com.example.inventory.dto;

public class CustomerDTO {

    private Long id;
    private Long userId;
    private String customerType;
    private Integer loyaltyPoints;

    public CustomerDTO() {}

    public CustomerDTO(Long id, Long userId, String customerType, Integer loyaltyPoints) {
        this.id = id;
        this.userId = userId;
        this.customerType = customerType;
        this.loyaltyPoints = loyaltyPoints;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getCustomerType() { return customerType; }
    public void setCustomerType(String customerType) { this.customerType = customerType; }

    public Integer getLoyaltyPoints() { return loyaltyPoints; }
    public void setLoyaltyPoints(Integer loyaltyPoints) { this.loyaltyPoints = loyaltyPoints; }
}
