package com.example.inventory.mapper;

import com.example.inventory.dto.DealerDTO;
import com.example.inventory.entity.Dealer;

public class DealerMapper {

    public static DealerDTO toDTO(Dealer d) {
        if (d == null) return null;

        return new DealerDTO(
                d.getId(),
                d.getUser().getId(),
                d.getCompanyName(),
                d.getGstNumber(),
                d.getDealerType()
        );
    }
}
