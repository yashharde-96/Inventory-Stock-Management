package com.example.inventory.mapper;

import com.example.inventory.dto.DealerDTO;
import com.example.inventory.entity.Dealer;

public final class DealerMapper {

    private DealerMapper() {}

    public static DealerDTO toDTO(Dealer dealer) {
        if (dealer == null) return null;

        return DealerDTO.builder()
                .id(dealer.getId())
                .userId(dealer.getUser().getId())
                .companyName(dealer.getCompanyName())
                .gstNumber(dealer.getGstNumber())
                .dealerType(dealer.getDealerType())
                .build();
    }
}
