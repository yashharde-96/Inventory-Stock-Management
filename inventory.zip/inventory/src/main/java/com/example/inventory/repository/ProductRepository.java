package com.example.inventory.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

	List<Product> findByQuantityLessThan(int minStockLevel);
    Page<Product> findByCategoryAndBrand(String category, String brand, Pageable pageable);
    Page<Product> findByCategory(String category, Pageable pageable);
    Page<Product> findByBrand(String brand, Pageable pageable);
    Page<Product> findByDealer(Dealer dealer, Pageable pageable);
	Page<Product> findByCategoryContainingAndBrandContaining(String category, String brand, Pageable pageable);
	void deleteById(Long id);

}