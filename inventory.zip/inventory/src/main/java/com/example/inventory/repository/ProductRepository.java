package com.example.inventory.repository;

import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {

    Page<Product> findByCategoryAndBrand(String category, String brand, Pageable pageable);
    Page<Product> findByCategory(String category, Pageable pageable);
    Page<Product> findByBrand(String brand, Pageable pageable);
    Page<Product> findByDealer(Dealer dealer, Pageable pageable);
	Page<Product> findByCategoryContainingAndBrandContaining(String category, String brand, Pageable pageable);
}
