package com.example.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.dto.BaseResponseDTO;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.service.UserService;
import com.example.inventory.util.SecurityUtil;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<UserDTO> getUser(@PathVariable Long id) {
        return new BaseResponseDTO<>("success","User fetched",userService.getUserById(id)
        );
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<List<UserDTO>> getAllUsers() {
        return new BaseResponseDTO<>("success","All users fetched",userService.getAllUsers());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<UserDTO> adminUpdateUser(
            @PathVariable Long id,
            @RequestBody UserDTO dto) {

        return new BaseResponseDTO<>("success","User updated by admin",userService.adminUpdateUser(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<Void> deleteUser(@PathVariable Long id) {

        userService.deleteUser(id);

        return BaseResponseDTO.<Void>builder().status("success").message("User deleted successfully").data(null).build();
    }

    @PutMapping("/me")
    @PreAuthorize("hasAnyAuthority('ADMIN','DEALER','CUSTOMER')")
    public BaseResponseDTO<UserDTO> updateMyProfile(@RequestBody UserDTO dto) {

        Long userId = SecurityUtil.getLoggedInUserId();

        return new BaseResponseDTO<>("success","Profile updated",userService.updateMyProfile(userId, dto));
    }
}