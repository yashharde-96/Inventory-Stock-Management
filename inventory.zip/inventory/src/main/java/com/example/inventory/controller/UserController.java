package com.example.inventory.controller;

import com.example.inventory.dto.BaseResponseDTO;
import com.example.inventory.dto.UserDTO;
import com.example.inventory.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<UserDTO> getUser(@PathVariable Long id) {
        return new BaseResponseDTO<>("success", "User fetched", userService.getUserById(id));
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<List<UserDTO>> getAllUsers() {
        return new BaseResponseDTO<>("success", "All users fetched", userService.getAllUsers());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<UserDTO> updateUser(@PathVariable Long id, @RequestBody UserDTO dto) {
        return new BaseResponseDTO<>("success", "User updated", userService.updateUser(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public BaseResponseDTO<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return new BaseResponseDTO<>("success", "User deleted", null);
    }
}
