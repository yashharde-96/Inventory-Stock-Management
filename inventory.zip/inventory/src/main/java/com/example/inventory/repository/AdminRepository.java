package com.example.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventory.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {
    void deleteByUserId(Long userId);
}
