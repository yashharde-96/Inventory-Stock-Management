package com.example.inventory.mapper;

import com.example.inventory.dto.CustomerDTO;
import com.example.inventory.entity.Customer;

public class CustomerMapper {

    public static CustomerDTO toDTO(Customer c) {
        if (c == null) return null;

        return new CustomerDTO(
                c.getId(),
                c.getUser().getId(),
                c.getCustomerType(),
                c.getLoyaltyPoints()
        );
    }
}
