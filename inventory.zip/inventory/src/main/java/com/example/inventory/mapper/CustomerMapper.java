package com.example.inventory.mapper;

import com.example.inventory.dto.CustomerDTO;
import com.example.inventory.entity.Customer;

public final class CustomerMapper {

    private CustomerMapper() {}

    public static CustomerDTO toDTO(Customer customer) {
        if (customer == null) return null;

        return CustomerDTO.builder()
                .id(customer.getId())
                .userId(customer.getUser().getId())
                .customerType(customer.getCustomerType())
                .loyaltyPoints(customer.getLoyaltyPoints())
                .build();
    }
}
