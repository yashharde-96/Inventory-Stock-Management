package com.example.inventory.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.ProductDTO;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;
import com.example.inventory.entity.Role;
import com.example.inventory.entity.User;
import com.example.inventory.mapper.ProductMapper;
import com.example.inventory.repository.CartRepository;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.ProductRepository;
import com.example.inventory.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private DealerRepository dealerRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CartRepository cartRepository;

    private static final Long DEFAULT_DEALER_ID = 1L;

    @Override
    public ProductDTO createProduct(ProductDTO dto, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole().getName() != Role.RoleName.DEALER) {
            throw new RuntimeException("Only dealers can add products");
        }

        Dealer dealer = dealerRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Dealer not found"));

        dto.setDealerId(dealer.getId());
        Product product = ProductMapper.toEntity(dto, dealer);
        product = productRepository.save(product);
        return ProductMapper.toDTO(product);
    }

    @Transactional
    @Override
    public ProductDTO updateProduct(Long productId, ProductDTO dto, Long userId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole().getName() != Role.RoleName.DEALER ||
                !product.getDealer().getUser().getId().equals(userId)) {
            throw new RuntimeException("Not authorized to update this product");
        }

        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setBrand(dto.getBrand());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setMinStockLevel(dto.getMinStockLevel());
        product.setImageUrl(dto.getImageUrl());

        productRepository.save(product);
        return ProductMapper.toDTO(product);
    }

    @Transactional
    @Override
    public void deleteProduct(Long productId, Long userId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole().getName() != Role.RoleName.DEALER ||
                !product.getDealer().getUser().getId().equals(userId)) {
            throw new RuntimeException("Not authorized to delete this product");
        }

        cartRepository.deleteByProduct_Id(productId);

        productRepository.delete(product);
    }

    @Override
    public ProductDTO getProduct(Long productId) {
        return productRepository.findById(productId)
                .map(ProductMapper::toDTO)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    @Override
    public Page<ProductDTO> getAllProducts(String category, String brand, Pageable pageable) {
        Page<Product> products;

        if (category != null && brand != null) {
            products = productRepository.findByCategoryContainingAndBrandContaining(category, brand, pageable);
        } else if (category != null) {
            products = productRepository.findByCategory(category, pageable);
        } else if (brand != null) {
            products = productRepository.findByBrand(brand, pageable);
        } else {
            products = productRepository.findAll(pageable);
        }

        return products.map(ProductMapper::toDTO);
    }

    @Transactional
    @Override
    public ProductDTO updateStock(Long productId, int delta, Long userId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole().getName() != Role.RoleName.DEALER ||
                !product.getDealer().getUser().getId().equals(userId)) {
            throw new RuntimeException("Not authorized to update stock");
        }

        int newQuantity = product.getQuantity() + delta;
        if (newQuantity < 0) throw new RuntimeException("Insufficient stock");

        product.setQuantity(newQuantity);
        productRepository.save(product);
        return ProductMapper.toDTO(product);
    }

    @Override
    public List<ProductDTO> getLowStock(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

        List<Product> products;

        if (user.getRole().getName() == Role.RoleName.ADMIN) {
            products = productRepository.findByQuantityLessThan(5); // threshold
        } else if (user.getRole().getName() == Role.RoleName.DEALER) {
            Dealer dealer = dealerRepository.findByUserId(userId)
                    .orElseThrow(() -> new RuntimeException("Dealer not found"));
            products = productRepository.findByDealer(dealer, Pageable.unpaged()).getContent().stream().filter(p -> p.getQuantity() < 5).collect(Collectors.toList());
        } else {
            throw new RuntimeException("Not authorized to view low stock");
        }

        return products.stream().map(ProductMapper::toDTO).collect(Collectors.toList());
    }

    @Override
    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll().stream().map(ProductMapper::toDTO).toList();
    }


}
