package com.example.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.ProductDTO;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;
import com.example.inventory.entity.TransactionLog;
import com.example.inventory.mapper.ProductMapper;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.ProductRepository;
import com.example.inventory.repository.TransactionLogRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;
   
    @Autowired
    private TransactionLogRepository transactionLogRepository;


    @Autowired
    private DealerRepository dealerRepository;

    @Override
    public ProductDTO createProduct(ProductDTO dto) {
        Dealer dealer = null;
        if(dto.getDealerId() != null) {
            dealer = dealerRepository.findById(dto.getDealerId())
                    .orElseThrow(() -> new RuntimeException("Dealer not found"));
        }

        Product product = ProductMapper.toEntity(dto, dealer);
        product = productRepository.save(product);
        return ProductMapper.toDTO(product);
    }

    @Override
    public ProductDTO getProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        return ProductMapper.toDTO(product);
    }

    @Override
    public Page<ProductDTO> getAllProducts(String category, String brand, Pageable pageable) {
        if(category == null) category = "";
        if(brand == null) brand = "";

        Page<Product> page = productRepository.findByCategoryContainingAndBrandContaining(category, brand, pageable);
        return page.map(ProductMapper::toDTO);
    }

    @Override
    public ProductDTO updateProduct(Long id, ProductDTO dto) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setBrand(dto.getBrand());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setMinStockLevel(dto.getMinStockLevel());

        if(dto.getDealerId() != null) {
            Dealer dealer = dealerRepository.findById(dto.getDealerId())
                    .orElseThrow(() -> new RuntimeException("Dealer not found"));
            product.setDealer(dealer);
        }

        product = productRepository.save(product);
        return ProductMapper.toDTO(product);
    }

    @Override
    public void deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        productRepository.delete(product);
    }

    @Override
    public ProductDTO updateStock(Long productId, int delta, Long dealerId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        if(dealerId != null && (product.getDealer() == null || !product.getDealer().getId().equals(dealerId))) {
            throw new RuntimeException("Unauthorized dealer");
        }

        int oldQuantity = product.getQuantity();
        int newQuantity = oldQuantity + delta;
        if(newQuantity < 0) newQuantity = 0;
        product.setQuantity(newQuantity);
        productRepository.save(product);

        // Save transaction log
        TransactionLog log = new TransactionLog();
        log.setProductId(productId);
        log.setUserId(dealerId);
        log.setChangeType(delta > 0 ? "INCREASE" : "DECREASE");
        log.setQuantityChanged(Math.abs(delta));
        transactionLogRepository.save(log);

        return ProductMapper.toDTO(product);
    }

}
