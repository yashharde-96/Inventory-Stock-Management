package com.example.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.inventory.dto.ProductDTO;
import com.example.inventory.entity.Dealer;
import com.example.inventory.entity.Product;
import com.example.inventory.entity.Role;
import com.example.inventory.entity.User;
import com.example.inventory.mapper.ProductMapper;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.ProductRepository;
import com.example.inventory.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private DealerRepository dealerRepository;

    @Autowired
    private UserRepository userRepository;

    private static final Long DEFAULT_DEALER_ID = 1L;

    @Override
    public ProductDTO createProduct(ProductDTO dto, Long userId) {
        Dealer dealer;
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole().getName() == Role.RoleName.DEALER) {
            dealer = dealerRepository.findByUserId(userId)
                    .orElseThrow(() -> new RuntimeException("Dealer not found for this user"));
            dto.setDealerId(dealer.getId());

        } else {
            if (dto.getDealerId() != null) {
                dealer = dealerRepository.findById(dto.getDealerId())
                        .orElseThrow(() -> new RuntimeException("Dealer not found"));
            } else {
                dealer = dealerRepository.findById(DEFAULT_DEALER_ID)
                        .orElseThrow(() -> new RuntimeException("Default dealer not found"));
                dto.setDealerId(dealer.getId());
            }
        }

        Product product = ProductMapper.toEntity(dto, dealer);
        product = productRepository.save(product);
        return ProductMapper.toDTO(product);
    }

    @Transactional
    public ProductDTO updateProduct(Long productId, ProductDTO dto, Long userId) {

        Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole().getName() == Role.RoleName.DEALER) {
            if (!product.getDealer().getUser().getId().equals(userId)) {
                throw new RuntimeException("Dealer not allowed to update this product");
            }
        }

        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setBrand(dto.getBrand());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setMinStockLevel(dto.getMinStockLevel());

        productRepository.save(product);

        return ProductMapper.toDTO(product);
    }

    @Override
    public void deleteProduct(Long productId, Long userId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole().getName() == Role.RoleName.DEALER) {
            Dealer dealer = dealerRepository.findByUserId(userId)
                    .orElseThrow(() -> new RuntimeException("Dealer not found"));
            if (!product.getDealer().getId().equals(dealer.getId())) {
                throw new RuntimeException("Not authorized to delete this product");
            }
        }

        productRepository.delete(product);
    }

    @Override
    public ProductDTO getProduct(Long productId) {
        return productRepository.findById(productId)
                .map(ProductMapper::toDTO)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    @Override
    public Page<ProductDTO> getAllProducts(String category, String brand, Pageable pageable) {
        return productRepository.findAll(pageable)
                .map(ProductMapper::toDTO);
    }

    @Transactional
    public ProductDTO updateStock(Long productId, int delta, Long userId) {

        Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));

        if (!product.getDealer().getUser().getId().equals(userId)) {
            throw new RuntimeException("You are not allowed to update this product");
        }

        int newQuantity = product.getQuantity() + delta;

        if (newQuantity < 0) {
            throw new RuntimeException("Insufficient stock");
        }

        product.setQuantity(newQuantity);
        productRepository.save(product);

        return ProductMapper.toDTO(product);
    }

}
